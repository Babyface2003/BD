﻿namespace Курсач_по_бд
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            N = new TextBox();
            label2 = new Label();
            m = new Label();
            label4 = new Label();
            b = new Label();
            label6 = new Label();
            label7 = new Label();
            z1 = new ComboBox();
            Fi = new TextBox();
            n2 = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            u = new Label();
            z2 = new Label();
            F = new Label();
            label14 = new Label();
            label15 = new Label();
            C1 = new Label();
            C2 = new Label();
            d1 = new Label();
            q = new TextBox();
            i = new ComboBox();
            d2 = new Label();
            n1 = new TextBox();
            ResultButton = new Button();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            label5 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(63, 44);
            label1.Name = "label1";
            label1.Size = new Size(130, 19);
            label1.TabIndex = 0;
            label1.Text = "Мощность, N = ";
            // 
            // N
            // 
            N.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            N.Location = new Point(195, 44);
            N.Name = "N";
            N.Size = new Size(121, 21);
            N.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(72, 101);
            label2.Name = "label2";
            label2.Size = new Size(117, 19);
            label2.TabIndex = 2;
            label2.Text = "Частота, n1 = ";
            // 
            // m
            // 
            m.AutoSize = true;
            m.BackColor = SystemColors.ButtonFace;
            m.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            m.ForeColor = Color.Black;
            m.Location = new Point(704, 42);
            m.Name = "m";
            m.Size = new Size(61, 23);
            m.TabIndex = 4;
            m.Text = "m = 0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 148);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 5;
            // 
            // b
            // 
            b.AutoSize = true;
            b.Font = new Font("Microsoft Sans Serif", 15F, FontStyle.Regular, GraphicsUnit.Point);
            b.Location = new Point(704, 72);
            b.Name = "b";
            b.Size = new Size(56, 25);
            b.TabIndex = 6;
            b.Text = "b = 0";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(30, 198);
            label6.Name = "label6";
            label6.Size = new Size(0, 15);
            label6.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(31, 248);
            label7.Name = "label7";
            label7.Size = new Size(0, 15);
            label7.TabIndex = 11;
            // 
            // z1
            // 
            z1.DropDownStyle = ComboBoxStyle.DropDownList;
            z1.FormattingEnabled = true;
            z1.Items.AddRange(new object[] { "12", "14", "16", "18", "20", "22", "24", "26", "27", "28" });
            z1.Location = new Point(195, 248);
            z1.Name = "z1";
            z1.Size = new Size(121, 23);
            z1.TabIndex = 12;
            // 
            // Fi
            // 
            Fi.Location = new Point(195, 158);
            Fi.Name = "Fi";
            Fi.Size = new Size(121, 23);
            Fi.TabIndex = 13;
            // 
            // n2
            // 
            n2.Location = new Point(195, 203);
            n2.Name = "n2";
            n2.Size = new Size(121, 23);
            n2.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(27, 251);
            label8.Name = "label8";
            label8.Size = new Size(162, 19);
            label8.TabIndex = 15;
            label8.Text = "Число зубьев, z1 = ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(27, 153);
            label9.Name = "label9";
            label9.Size = new Size(157, 19);
            label9.TabIndex = 16;
            label9.Text = "Коэффициент, Fi =";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(64, 207);
            label10.Name = "label10";
            label10.Size = new Size(117, 19);
            label10.TabIndex = 17;
            label10.Text = "Частота , n2 =";
            // 
            // u
            // 
            u.AutoSize = true;
            u.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            u.Location = new Point(704, 97);
            u.Name = "u";
            u.Size = new Size(55, 23);
            u.TabIndex = 18;
            u.Text = "u = 0";
            // 
            // z2
            // 
            z2.AutoSize = true;
            z2.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            z2.Location = new Point(704, 123);
            z2.Name = "z2";
            z2.Size = new Size(65, 23);
            z2.TabIndex = 19;
            z2.Text = "z2 = 0";
            // 
            // F
            // 
            F.AutoSize = true;
            F.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            F.Location = new Point(704, 153);
            F.Name = "F";
            F.Size = new Size(57, 23);
            F.TabIndex = 20;
            F.Text = "F = 0";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(47, 327);
            label14.Name = "label14";
            label14.Size = new Size(147, 19);
            label14.TabIndex = 21;
            label14.Text = "Коэффициент, i =";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label15.Location = new Point(47, 288);
            label15.Name = "label15";
            label15.Size = new Size(134, 19);
            label15.TabIndex = 22;
            label15.Text = "Расстояние, q =";
            // 
            // C1
            // 
            C1.AutoSize = true;
            C1.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            C1.Location = new Point(704, 179);
            C1.Name = "C1";
            C1.Size = new Size(70, 23);
            C1.TabIndex = 23;
            C1.Text = "C1 = 0";
            // 
            // C2
            // 
            C2.AutoSize = true;
            C2.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            C2.Location = new Point(704, 210);
            C2.Name = "C2";
            C2.Size = new Size(70, 23);
            C2.TabIndex = 24;
            C2.Text = "C2 = 0";
            // 
            // d1
            // 
            d1.AutoSize = true;
            d1.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            d1.Location = new Point(704, 233);
            d1.Name = "d1";
            d1.Size = new Size(67, 23);
            d1.TabIndex = 25;
            d1.Text = "d1 = 0";
            // 
            // q
            // 
            q.Location = new Point(195, 284);
            q.Name = "q";
            q.Size = new Size(121, 23);
            q.TabIndex = 26;
            // 
            // i
            // 
            i.DropDownStyle = ComboBoxStyle.DropDownList;
            i.FormattingEnabled = true;
            i.Items.AddRange(new object[] { "0,0018", "0,0025", "0,003", "0,0011", "0,0013", "0,0019", "0,0025" });
            i.Location = new Point(195, 327);
            i.Name = "i";
            i.Size = new Size(121, 23);
            i.TabIndex = 32;
            // 
            // d2
            // 
            d2.AutoSize = true;
            d2.Font = new Font("Arial", 15F, FontStyle.Regular, GraphicsUnit.Point);
            d2.Location = new Point(704, 263);
            d2.Name = "d2";
            d2.Size = new Size(67, 23);
            d2.TabIndex = 39;
            d2.Text = "d2 = 0";
            // 
            // n1
            // 
            n1.Location = new Point(195, 98);
            n1.Name = "n1";
            n1.Size = new Size(121, 23);
            n1.TabIndex = 40;
            // 
            // ResultButton
            // 
            ResultButton.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ResultButton.Location = new Point(406, 327);
            ResultButton.Name = "ResultButton";
            ResultButton.Size = new Size(177, 43);
            ResultButton.TabIndex = 41;
            ResultButton.Text = "Рассчитать";
            ResultButton.UseVisualStyleBackColor = true;
            ResultButton.Click += ResultButton_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 388);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(593, 435);
            pictureBox1.TabIndex = 42;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(673, 9);
            label3.Name = "label3";
            label3.Size = new Size(122, 15);
            label3.TabIndex = 43;
            label3.Text = "Реузльтаты расчётов";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(66, 5);
            label5.Name = "label5";
            label5.Size = new Size(65, 15);
            label5.TabIndex = 44;
            label5.Text = "Парметры";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(552, 46);
            label11.Name = "label11";
            label11.Size = new Size(146, 15);
            label11.TabIndex = 45;
            label11.Text = "Модуль зубчатого ремня";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(608, 76);
            label12.Name = "label12";
            label12.Size = new Size(90, 15);
            label12.TabIndex = 46;
            label12.Text = "Ширина ремня";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(575, 101);
            label13.Name = "label13";
            label13.Size = new Size(123, 15);
            label13.TabIndex = 47;
            label13.Text = "Передаточное число";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(519, 130);
            label16.Name = "label16";
            label16.Size = new Size(179, 15);
            label16.TabIndex = 48;
            label16.Text = "Число зубьев большего шкива";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(594, 158);
            label17.Name = "label17";
            label17.Size = new Size(104, 15);
            label17.TabIndex = 49;
            label17.Text = "Рабочая нагрузка";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(473, 186);
            label18.Name = "label18";
            label18.Size = new Size(225, 15);
            label18.TabIndex = 50;
            label18.Text = "Поправка на диаметр меньшего шкива";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(474, 214);
            label19.Name = "label19";
            label19.Size = new Size(224, 15);
            label19.TabIndex = 51;
            label19.Text = "Поправка на диаметр большего шкива";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(520, 240);
            label20.Name = "label20";
            label20.Size = new Size(178, 15);
            label20.TabIndex = 52;
            label20.Text = "Диаметр через меньший шкив";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(521, 270);
            label21.Name = "label21";
            label21.Size = new Size(177, 15);
            label21.TabIndex = 53;
            label21.Text = "Диаметр через больший шкив";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(870, 835);
            ControlBox = false;
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(ResultButton);
            Controls.Add(n1);
            Controls.Add(d2);
            Controls.Add(i);
            Controls.Add(q);
            Controls.Add(d1);
            Controls.Add(C2);
            Controls.Add(C1);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(F);
            Controls.Add(z2);
            Controls.Add(u);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(n2);
            Controls.Add(Fi);
            Controls.Add(z1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(b);
            Controls.Add(label4);
            Controls.Add(m);
            Controls.Add(label2);
            Controls.Add(N);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.Black;
            Name = "Form1";
            Text = "Проектировочный расчёт";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox N;
        private Label label2;
        private Label m;
        private Label label4;
        private Label b;
        private Label label6;
        private Label label7;
        private ComboBox z1;
        private TextBox Fi;
        private TextBox n2;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label u;
        private Label z2;
        private Label F;
        private Label label14;
        private Label label15;
        private Label C1;
        private Label C2;
        private Label d1;
        private TextBox q;
        private ComboBox i;
        private Label d2;
        private TextBox n1;
        private Button ResultButton;
        private PictureBox pictureBox1;
        private Label label3;
        private Label label5;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
    }
}